# Builds the release zip: folder build (exe + _internal, no Python needed on the target PC),
# readme, patcher source and SHA-256 sums.
# A folder build avoids the onefile self-extraction that antivirus heuristics often flag.
# PyInstaller runs under a short temp path: the session folder path is too long for MAX_PATH.
$py = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"
$version = "1.0.0"
$name = "RailOfMobius_KoreanPatch"
$tmp = Join-Path $env:TEMP "rmkp_build"
$stage = Join-Path $tmp "${name}_v$version"

Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force (Join-Path $tmp "src\data") | Out-Null
Copy-Item (Join-Path $PSScriptRoot "korean_patch.py") (Join-Path $tmp "src")
Copy-Item (Join-Path $PSScriptRoot "data\ko.jsonl") (Join-Path $tmp "src\data")

Push-Location (Join-Path $tmp "src")
try {
    # PyInstaller logs to stderr; run through cmd so PowerShell doesn't treat that as an error
    cmd /c "`"$py`" -m PyInstaller --noconfirm --clean --onedir --windowed --name $name --distpath `"$tmp\dist`" --workpath `"$tmp\work`" --specpath `"$tmp`" --add-data `"$tmp\src\data\ko.jsonl;data`" --collect-all UnityPy --exclude-module TypeTreeGeneratorAPI --exclude-module matplotlib --exclude-module numpy korean_patch.py > `"$tmp\pyinstaller.log`" 2>&1"
    if ($LASTEXITCODE -ne 0) { throw "PyInstaller failed ($LASTEXITCODE), see $tmp\pyinstaller.log" }
} finally {
    Pop-Location
}

New-Item -ItemType Directory -Force $stage | Out-Null
Copy-Item (Join-Path $tmp "dist\$name") (Join-Path $stage $name) -Recurse
# the readme has a Korean file name; match it by extension because PowerShell 5.1 reads this
# BOM-less script as the ANSI code page and would mangle a Korean literal
Get-ChildItem $PSScriptRoot -Filter "*.txt" | Copy-Item -Destination $stage
New-Item -ItemType Directory -Force (Join-Path $stage "source") | Out-Null
Copy-Item (Join-Path $PSScriptRoot "korean_patch.py"), (Join-Path $PSScriptRoot "build.ps1") (Join-Path $stage "source")

$exe = Join-Path $stage "$name\$name.exe"
$sums = Get-ChildItem $stage -Recurse -File | Where-Object { $_.FullName -eq $exe -or $_.Directory.FullName -eq $stage } |
    ForEach-Object { "{0}  {1}" -f (Get-FileHash $_.FullName).Hash.ToLower(), $_.FullName.Substring($stage.Length + 1) }
[IO.File]::WriteAllLines((Join-Path $stage "SHA256SUMS.txt"), $sums, (New-Object Text.UTF8Encoding $false))

$out = Join-Path $PSScriptRoot "release"
New-Item -ItemType Directory -Force $out | Out-Null
$zip = Join-Path $out "${name}_v$version.zip"
Compress-Archive -Path $stage -DestinationPath $zip -Force
Write-Output "built $zip"
Write-Output "test copy: $stage"
