"""Rail of Möbius (湛藍牢籠) 비공식 한글 패치 설치/제거 프로그램.

The game keeps its Utage scenario in two identical places, and Unity caches the bundle copy:
  - RailOfMobius_Data/StreamingAssets/TEST_13TH/Windows/test_13th.scenarios.asset
  - RailOfMobius_Data/sharedassets0.assets (embedded copy, no type trees -> reuse the bundle's)
  - %USERPROFILE%/AppData/LocalLow/Unity/<company>_<product>/test_13th.scenarios (bundle cache)
The patch is generated from the user's own original files; no game data ships with it.

usage: korean_patch.exe                      (GUI)
       korean_patch.exe --status|--install|--uninstall [--game-dir DIR]
"""
import sys, os, re, json, glob, shutil, hashlib, subprocess, threading, argparse

PATCH_VERSION = "1.0.0"
GAME_BUILD = "13230446"
EXE_NAME = "RailOfMobius.exe"
BUNDLE_REL = os.path.join("RailOfMobius_Data", "StreamingAssets", "TEST_13TH", "Windows", "test_13th.scenarios.asset")
SHARED_REL = os.path.join("RailOfMobius_Data", "sharedassets0.assets")
MARKER_REL = os.path.join("RailOfMobius_Data", "korean_patch.json")
ORIG_HASH = {
    BUNDLE_REL: "69683943158c9f9074a40880071675f20fd39ebf4b56037c179edc3339a11da4",
    SHARED_REL: "9e297771ff9a891cdf1cbb1ee99db1cbd5572ced75d782fb42ca998cc9de7fda",
}
GD_NAMES = {
    "DA": "DA", "Ibuki": "이부키", "Jim": "짐", "Wang": "왕", "Howard": "하워드",
    "Lori": "로리", "WannaSinging": "노래하고파", "Rie": "리에", "Riku": "리쿠",
    "Miranda": "미란다", "Ava": "에이바",
}
NOTICE = (
    "비공식 팬 번역 패치입니다. 게임과 원문의 저작권은 PHOSEPO에 있습니다.\n"
    f"대상: Steam판 빌드 {GAME_BUILD} · 번역은 영어판을 바탕으로 한 AI 번역을 검수한 것입니다."
)


class PatchError(Exception):
    pass


def resource_path(*parts):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


# ---------------------------------------------------------------- locating the game

def steam_libraries():
    roots = []
    try:
        import winreg
        for hive, key, val in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                               (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath")):
            try:
                with winreg.OpenKey(hive, key) as k:
                    roots.append(os.path.normpath(winreg.QueryValueEx(k, val)[0]))
            except OSError:
                pass
    except ImportError:
        pass
    roots.append(r"C:\Program Files (x86)\Steam")
    libs = []
    for root in roots:
        vdf = os.path.join(root, "steamapps", "libraryfolders.vdf")
        if os.path.exists(vdf):
            text = open(vdf, encoding="utf-8", errors="replace").read()
            libs += [p.replace("\\\\", "\\") for p in re.findall(r'"path"\s+"([^"]+)"', text)]
        libs.append(root)
    seen, out = set(), []
    for p in libs:
        p = os.path.normpath(p)
        if os.path.normcase(p) not in seen:
            seen.add(os.path.normcase(p))
            out.append(p)
    return out


def find_game_dir():
    for lib in steam_libraries():
        cand = os.path.join(lib, "steamapps", "common", "Rail of Mobius")
        if os.path.exists(os.path.join(cand, EXE_NAME)):
            return cand
    return None


def normalize_game_dir(text):
    """Accept a pasted game folder, RailOfMobius.exe path, or RailOfMobius_Data folder (quotes allowed)."""
    p = text.strip().strip('"').strip("'").strip()
    if not p:
        return ""
    p = os.path.normpath(os.path.expandvars(p))
    if os.path.basename(p).lower() == EXE_NAME.lower():
        p = os.path.dirname(p)
    while p and not os.path.exists(os.path.join(p, EXE_NAME)):
        parent = os.path.dirname(p)
        if parent == p:
            return os.path.normpath(text.strip().strip('"'))
        p = parent
    return p


def unity_cache_dirs(game_dir):
    """Unity's bundle cache folders for this game (LocalLow/Unity/<Company>_<Product>/test_13th.scenarios)."""
    base = os.path.join(os.path.expanduser("~"), "AppData", "LocalLow", "Unity")
    dirs = set()
    info = os.path.join(game_dir, "RailOfMobius_Data", "app.info")
    if os.path.exists(info):
        company, product = (open(info, encoding="utf-8").read().splitlines() + ["", ""])[:2]
        dirs.add(os.path.join(base, f"{company.replace('.', '_')}_{product}", "test_13th.scenarios"))
    dirs.update(glob.glob(os.path.join(base, "*湛藍牢籠*", "test_13th.scenarios")))
    return [d for d in dirs if os.path.isdir(d)]


def game_running():
    try:
        out = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {EXE_NAME}"], capture_output=True,
                             text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
        return EXE_NAME.lower() in out.lower()
    except OSError:
        return False


# ---------------------------------------------------------------- state

def status(game_dir):
    """Returns ('not_installed' | 'installed' | 'unknown', message)."""
    if not game_dir or not os.path.exists(os.path.join(game_dir, EXE_NAME)):
        return "unknown", "게임 폴더를 찾지 못했습니다."
    states = []
    for rel, h in ORIG_HASH.items():
        path = os.path.join(game_dir, rel)
        if not os.path.exists(path):
            return "unknown", f"파일이 없습니다: {rel}"
        if sha256(path) == h:
            states.append("orig")
        elif os.path.exists(path + ".orig") and sha256(path + ".orig") == h:
            states.append("patched")
        else:
            states.append("other")
    if all(s == "orig" for s in states):
        return "not_installed", "한글 패치가 설치되어 있지 않습니다."
    if all(s == "patched" for s in states):
        return "installed", "한글 패치가 설치되어 있습니다."
    if "other" in states:
        return "unknown", ("게임 파일이 이 패치가 지원하는 버전과 다릅니다(게임 업데이트 등).\n"
                           "Steam에서 '게임 파일 무결성 확인'을 한 뒤 다시 시도하거나 새 버전 패치를 기다려 주세요.")
    return "unknown", "일부 파일만 패치된 상태입니다. '패치 제거' 후 다시 설치해 주세요."


# ---------------------------------------------------------------- patching

def load_translations():
    tr = {}
    with open(resource_path("data", "ko.jsonl"), encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rec = json.loads(line)
                if rec.get("ko"):
                    tr[rec["id"]] = rec["ko"]
    return tr


def apply_tree(tree, tr):
    applied = 0
    if "importGridList" in tree:
        for gi, g in enumerate(tree["importGridList"]):
            hdr = g["rows"][0]["strings"]
            if "Text" not in hdr:
                continue
            ti = hdr.index("Text")
            for ri, r in enumerate(g["rows"]):
                st = r["strings"]
                ko = tr.get(f"{gi}:{ri}")
                if ko is not None and ti < len(st):
                    st[ti] = ko
                    applied += 1
                if st and st[0] == "Param" and len(st) > 1:
                    m = re.fullmatch(r'GDName="(.*)"', st[1])
                    if m and m.group(1) in GD_NAMES:
                        st[1] = f'GDName="{GD_NAMES[m.group(1)]}"'
    if "settingList" in tree:
        for s in tree["settingList"]:
            if s["name"].endswith(":Localize"):
                for ri, r in enumerate(s["rows"]):
                    ko = tr.get(f"L:{ri}")
                    if ko is not None and len(r["strings"]) >= 2:
                        r["strings"][1] = ko
                        applied += 1
    return applied


def read_bytes(path):
    # load from memory so no handle stays open on the files we are about to replace
    with open(path, "rb") as f:
        return f.read()


def build_patched(bundle_src, shared_src, tr, log):
    import UnityPy
    log("시나리오 번들을 읽는 중...")
    benv = UnityPy.load(read_bytes(bundle_src))
    nodes, n_bundle = {}, 0
    for obj in benv.objects:
        if obj.type.name != "MonoBehaviour":
            continue
        tree = obj.read_typetree()
        if "importGridList" in tree or "settingList" in tree:
            nodes["book" if "importGridList" in tree else "chapter"] = obj.serialized_type.node
            n_bundle += apply_tree(tree, tr)
            obj.save_typetree(tree)
    bundle_bytes = benv.file.save(packer="lz4")

    log("내장 시나리오(sharedassets0)를 읽는 중... (조금 걸립니다)")
    senv = UnityPy.load(read_bytes(shared_src))
    n_shared = 0
    for obj in senv.objects:
        if obj.type.name != "MonoBehaviour" or obj.byte_size < 100000:
            continue
        for kind, node in nodes.items():
            try:
                tree = obj.read_typetree(nodes=node)
            except Exception:
                continue
            if ("importGridList" in tree) != (kind == "book"):
                continue
            n_shared += apply_tree(tree, tr)
            obj.save_typetree(tree, nodes=node)
            break
    shared_bytes = senv.file.save()
    if n_bundle != len(tr) or n_shared != len(tr):
        raise PatchError(f"번역 적용 개수가 맞지 않습니다 (번들 {n_bundle}, 내장 {n_shared}, 번역 {len(tr)}).")
    log(f"번역 {len(tr):,}개 적용 완료")
    return bundle_bytes, shared_bytes


def clear_cache(game_dir, log):
    for d in unity_cache_dirs(game_dir):
        shutil.rmtree(d, ignore_errors=True)
        log(f"Unity 캐시 정리: {d}")


def install(game_dir, log=print):
    if game_running():
        raise PatchError("게임이 실행 중입니다. 게임을 종료한 뒤 다시 시도해 주세요.")
    st, msg = status(game_dir)
    if st == "installed":
        log("이미 설치되어 있습니다. 다시 적용합니다.")
        uninstall(game_dir, log)
    elif st != "not_installed":
        raise PatchError(msg)
    tr = load_translations()
    bundle = os.path.join(game_dir, BUNDLE_REL)
    shared = os.path.join(game_dir, SHARED_REL)
    bundle_bytes, shared_bytes = build_patched(bundle, shared, tr, log)
    log("원본 백업 및 파일 교체 중...")
    done = []
    try:
        for path, data in ((bundle, bundle_bytes), (shared, shared_bytes)):
            shutil.copy2(path, path + ".orig")
            tmp = path + ".kotmp"
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, path)
            done.append(path)
    except OSError as e:
        # roll back whatever was already replaced so the game stays playable
        for path in (bundle, shared):
            if os.path.exists(path + ".kotmp"):
                os.remove(path + ".kotmp")
            if path in done:
                os.replace(path + ".orig", path)
            elif os.path.exists(path + ".orig"):
                os.remove(path + ".orig")
        raise PatchError(f"파일을 교체하지 못해 원래대로 되돌렸습니다: {e}\n"
                         "게임과 Steam 검증이 끝났는지 확인하고, 안 되면 관리자 권한으로 실행해 주세요.")
    with open(os.path.join(game_dir, MARKER_REL), "w", encoding="utf-8") as f:
        json.dump({"patch_version": PATCH_VERSION, "game_build": GAME_BUILD}, f)
    clear_cache(game_dir, log)
    log("설치가 끝났습니다. 게임을 실행해 보세요.")


def uninstall(game_dir, log=print):
    if game_running():
        raise PatchError("게임이 실행 중입니다. 게임을 종료한 뒤 다시 시도해 주세요.")
    restored = 0
    for rel, h in ORIG_HASH.items():
        path = os.path.join(game_dir, rel)
        orig = path + ".orig"
        if os.path.exists(orig):
            if sha256(orig) != h:
                raise PatchError(f"백업 파일이 원본과 다릅니다: {orig}\nSteam '게임 파일 무결성 확인'으로 복구해 주세요.")
            os.replace(orig, path)
            restored += 1
    marker = os.path.join(game_dir, MARKER_REL)
    if os.path.exists(marker):
        os.remove(marker)
    clear_cache(game_dir, log)
    log("원본으로 복원했습니다." if restored else "복원할 백업이 없었습니다.")


# ---------------------------------------------------------------- GUI

def run_gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox, scrolledtext

    root = tk.Tk()
    root.title(f"Rail of Möbius 한글 패치 v{PATCH_VERSION}")
    root.geometry("620x440")
    root.minsize(520, 380)
    frm = ttk.Frame(root, padding=14)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Rail of Möbius (湛藍牢籠) 한글 패치", font=("Malgun Gothic", 14, "bold")).pack(anchor="w")
    ttk.Label(frm, text=NOTICE, foreground="#555", justify="left").pack(anchor="w", pady=(4, 10))

    row = ttk.Frame(frm)
    row.pack(fill="x")
    ttk.Label(row, text="게임 폴더").pack(side="left")
    path_var = tk.StringVar(value=find_game_dir() or "")
    ttk.Entry(row, textvariable=path_var).pack(side="left", fill="x", expand=True, padx=6)
    ttk.Label(frm, text="자동으로 못 찾으면 게임 폴더(또는 RailOfMobius.exe) 경로를 붙여넣거나 [찾아보기]를 누르세요.",
              foreground="#777").pack(anchor="w", pady=(2, 0))

    status_var = tk.StringVar()
    ttk.Label(frm, textvariable=status_var, font=("Malgun Gothic", 10, "bold")).pack(anchor="w", pady=(10, 6))

    btns = ttk.Frame(frm)
    btns.pack(fill="x")
    log_box = scrolledtext.ScrolledText(frm, height=10, state="disabled", font=("Malgun Gothic", 9))
    log_box.pack(fill="both", expand=True, pady=(10, 0))

    def log(msg):
        def put():
            log_box.configure(state="normal")
            log_box.insert("end", msg + "\n")
            log_box.see("end")
            log_box.configure(state="disabled")
        root.after(0, put)

    busy = [False]

    def game_dir():
        return normalize_game_dir(path_var.get())

    def refresh(*_):
        if busy[0]:
            return
        d = game_dir()
        st, msg = status(d)
        status_var.set(msg)
        install_btn.configure(state="normal" if st in ("not_installed", "installed") else "disabled")
        remove_btn.configure(state="normal" if st == "installed" or os.path.exists(
            os.path.join(d, BUNDLE_REL) + ".orig") else "disabled")

    def on_path_edit(*_):
        # re-check shortly after typing/pasting stops (hashing takes a moment)
        if pending[0]:
            root.after_cancel(pending[0])
        pending[0] = root.after(400, refresh)

    pending = [None]

    def browse():
        d = filedialog.askdirectory(title=f"{EXE_NAME}가 있는 폴더를 선택하세요")
        if d:
            path_var.set(os.path.normpath(d))

    def run(action, label):
        busy[0] = True
        for b in (install_btn, remove_btn, browse_btn):
            b.configure(state="disabled")
        d = game_dir()
        log(f"--- {label} 시작 ({d}) ---")

        def done():
            busy[0] = False
            browse_btn.configure(state="normal")
            refresh()

        def work():
            try:
                action(d, log)
                root.after(0, lambda: messagebox.showinfo("완료", f"{label}이(가) 끝났습니다."))
            except Exception as e:
                log(f"오류: {e}")
                root.after(0, lambda: messagebox.showerror("오류", str(e)))
            finally:
                root.after(0, done)
        threading.Thread(target=work, daemon=True).start()

    browse_btn = ttk.Button(row, text="찾아보기", command=browse)
    browse_btn.pack(side="left")
    install_btn = ttk.Button(btns, text="한글 패치 설치", command=lambda: run(install, "설치"))
    install_btn.pack(side="left")
    remove_btn = ttk.Button(btns, text="패치 제거 (원본 복원)", command=lambda: run(uninstall, "제거"))
    remove_btn.pack(side="left", padx=8)

    if path_var.get():
        log(f"Steam에서 게임 폴더를 찾았습니다: {path_var.get()}")
    else:
        log("Steam 라이브러리에서 게임을 찾지 못했습니다. 경로를 붙여넣거나 '찾아보기'로 지정해 주세요.")
    path_var.trace_add("write", on_path_edit)
    refresh()
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description="Rail of Möbius 한글 패치")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--status", action="store_true")
    g.add_argument("--install", action="store_true")
    g.add_argument("--uninstall", action="store_true")
    ap.add_argument("--game-dir")
    args = ap.parse_args()
    if not (args.status or args.install or args.uninstall):
        run_gui()
        return
    if sys.stdout:
        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
    game_dir = normalize_game_dir(args.game_dir) if args.game_dir else find_game_dir()
    try:
        if args.status:
            print(game_dir, "|", status(game_dir)[1])
        elif args.install:
            install(game_dir)
        else:
            uninstall(game_dir)
    except PatchError as e:
        print("오류:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
